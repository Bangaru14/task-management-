module.exports = {
    jwtSecret: process.env.JWT_SECRET || '9uf41dz6m6ygusrvj3lx7fucdqt4383h',
};
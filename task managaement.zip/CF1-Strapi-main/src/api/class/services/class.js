'use strict';

/**
 * class service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::class.class');

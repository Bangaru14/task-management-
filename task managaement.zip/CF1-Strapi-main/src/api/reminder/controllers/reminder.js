'use strict';

/**
 * reminder controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::reminder.reminder');
